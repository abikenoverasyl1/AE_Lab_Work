with open(r"C:\Users\Student\Downloads\Football Clubs.txt", "r") as file:
    kolichestvo = []
    for line in file:
        name, cham_leagues = line.strip().split(", ")
        kolichestvo.append(int(cham_leagues))
        print(f"{name} — {cham_leagues}")
    print("Average champions league:", sum(kolichestvo) / len(kolichestvo))



name = input("Enter football club name: ")
cham_leagues = input("Enter champions league titles: ")

with open(r"C:\Users\Student\Downloads\Football Clubs.txt", "a") as file:
    file.write(f"\n{name}, {cham_leagues}")

print("Football club uspeshno dobavlen")
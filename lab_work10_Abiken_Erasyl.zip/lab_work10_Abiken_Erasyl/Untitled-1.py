with open("students.txt", "r") as file:
    scores = []
    for line in file:
        name, grade = line.strip().split(", ")
        scores.append(int(grade))
        print(f"{name} — {grade}")
    print("Average score:", sum(scores) / len(scores))
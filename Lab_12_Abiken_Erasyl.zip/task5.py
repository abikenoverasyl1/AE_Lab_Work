from abc import ABC, abstractmethod

class Pay(ABC):
    @abstractmethod
    def process(self): pass

class Kaspi(Pay):
    def process(self): print("Kaspi paid")

class PayPal(Pay):
    def process(self): print("PayPal paid")

Kaspi().process()
PayPal().process()

from abc import ABC, abstractmethod

class Logger(ABC):
    def header(self): print("LOG:")
    @abstractmethod
    def log(self, msg): pass

class FightLog(Logger):
    def log(self, msg): print("UFC:", msg)

l = FightLog()
l.header()
l.log("Fight started")

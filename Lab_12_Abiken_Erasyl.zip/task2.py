from abc import ABC, abstractmethod

class DB(ABC):
    @abstractmethod
    def connect(self): pass

class FootballDB(DB):
    def connect(self): print("Football DB connected")

class UFCDB(DB):
    def connect(self): print("UFC DB connected")

FootballDB().connect()
UFCDB().connect()

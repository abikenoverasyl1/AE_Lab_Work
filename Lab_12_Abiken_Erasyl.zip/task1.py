from abc import ABC, abstractmethod

class Sport(ABC):
    @abstractmethod
    def play(self): pass

class Football(Sport):
    def play(self): print("Football match!")

class UFC(Sport):
    def play(self): print("UFC fight!")

Football().play()
UFC().play()
class Footballer:
    def move(self): print("Runs on field")

class Fighter:
    def move(self): print("Moves in octagon")

for a in [Footballer(), Fighter()]:
    a.move()
